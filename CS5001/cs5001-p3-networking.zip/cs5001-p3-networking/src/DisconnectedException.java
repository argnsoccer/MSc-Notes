public class DisconnectedException extends Exception {

	public DisconnectedException(String message) {
		super(message);
	}
}